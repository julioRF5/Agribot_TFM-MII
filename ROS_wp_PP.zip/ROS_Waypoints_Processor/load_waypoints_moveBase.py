#!/usr/bin/env python
# coding:utf-8

import rospy
import actionlib
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped, Point, Quaternion
from mbf_msgs.msg import ExePathAction, ExePathGoal


def load_waypoints(waypoints_path):

    # Read the waypoints_file
    waypoints = []
    waypoints_file = open(waypoints_path)
    for line in waypoints_file.readlines():
        waypoints.append([float(i) for i in line.split(',')])
    waypoints_file.close()

    # Generate the waypoints_info
    waypoints_info = Path()
    waypoints_info.header.frame_id = 'odom'
    waypoints_info.header.stamp = rospy.Time.now()

    for idx in range(len(waypoints)-1):
        pose = PoseStamped()
        pose.header.frame_id = 'odom'
        pose.pose.position = Point(waypoints[idx][0], waypoints[idx][1], waypoints[idx][2])
        pose.pose.orientation = Quaternion(waypoints[idx][3], waypoints[idx][4], waypoints[idx][5], 1.0)
        
        waypoints_info.poses.append(pose)
    
    rospy.loginfo('Fetched ' + str(len(waypoints)) + ' waypoints')

    if waypoints == []:
        rospy.signal_shutdown('No waypoint to draw... Shutdown')

    return waypoints_info

# ## sobra ----
# def main():

#     rospy.init_node('waypoints_loader')
#     #crear el cliente

#     #waypoint_pub = rospy.Publisher('/move_base/TebLocalPlannerROS/local_plan', Path, queue_size=1)
#     rate = rospy.Rate(1)

#     waypoints_path = rospy.get_param("load_waypoints/waypoints_path")
#     waypoints_info = load_waypoints(waypoints_path)

#     while not rospy.is_shutdown():
#         waypoint_pub.publish(waypoints_info)
#         rate.sleep()
# #-----

if __name__ == "__main__":
    try:    
        rospy.init_node('waypoints_loader')
        waypoints_info = Path()
        #declaro el cliente
        client = actionlib.SimpleActionClient('/move_base_flex/exe_path/', ExePathAction)
        
        waypoints_path = "./waypoints_files/waypoints.txt"
        waypoints_info = load_waypoints(waypoints_path)
        #Wait for server (esperar a que el cliente este listo)
        client.wait_for_server()
        #Creo el goal exepath.gol

        goal = ExePathGoal()
        #publico el goal. 
        goal.path = waypoints_info
        
        while not rospy.is_shutdown():
                           

        #waypoint_pub = rospy.Publisher('/waypoints', Path, queue_size=1)
        #waypoint_pub.publish(goal.path)

            # borrar waypoint_pub.publish(waypoints_info)
            #borrar rate.sleep()

            client.send_goal(goal)
        #Espero el resultado
            client.wait_for_result(rospy.Duration.from_sec(1.0))
        

        
    except rospy.ROSInterruptException:
        rospy.logerr('Get KeyBoardInterrupt... Shutdown')